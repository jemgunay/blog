>>>>>>>>>>>>>>>>>>>>>>>>>>[ How to Use ]<<<<<<<<<<<<<<<<<<<<<<<<<<


To compile:
> "cd games_cw"
> "make"

To launch:
> "cd games_cw"
> "./MazeGame"
> (click accept button)

(Tested on Games Computing Ubuntu Virtual Machine, could not get access to Reeves labs)


>>>>>>>>>>>>>>>>>>>>>>>>[ File Locations ]<<<<<<<<<<<<<<<<<<<<<<<<


./games_cw/                 > Source code (cpp & header), object, config, level, game executable files
./games_cw/Assets/fonts     > font ttfs and fontdef files
./games_cw/Assets/materials > material files
./games_cw/Assets/meshes    > mesh files
./games_cw/Assets/overlays  > overlay files
./games_cw/Assets/textures  > texture image files


>>>>>>>>>>>>>>>>>>>>>>>>>[ How to Play ]<<<<<<<<<<<<<<<<<<<<<<<<<<


Roll upwards:   W key or UP key
Roll downwards: S key or DOWN key
Roll left:      A key or LEFT key
Roll right:     D key or RIGHT key
Close/exit:     ESCAPE key

Once all cheese segments have been collected, click the play again button to reset and replay the level.