document.addEventListener('DOMContentLoaded', function() {
	// init
	var first_msg = "CONSUME YOUR BEVERAGE!";
	var second_msg = "JELLY SHOT!";
	var third_msg = "TEQUILA SHOT!";
	var play_duration = 40; // seconds
	var timer, timer2;
	var lower_time, upper_time, reply_msg;

	// click event listeners
	// start & stop buttons
	var start_btn = document.getElementById('start-stop-btn');
	start_btn.addEventListener("click", function() {
		start_btn_press();
	}, false);

	var skip_btn = document.getElementById('skip-btn');
	skip_btn.addEventListener("click", function() {
		if (skip_btn.disabled == false) {
			stopAll(false);
		}
	}, false);

	// change message buttons
	var first_msg_btn = document.getElementById('first-msg');
	first_msg_btn.addEventListener("click", function() {
		reply_msg = prompt("Message for first song:", first_msg);
		if (reply_msg != null)
			first_msg = reply_msg;
	}, false);

	var second_msg_btn = document.getElementById('second-msg');
	second_msg_btn.addEventListener("click", function() {
		reply_msg = prompt("Message for second song:", second_msg);
		if (reply_msg != null)
			second_msg = reply_msg;
	}, false);

	var third_msg_btn = document.getElementById('third-msg');
	third_msg_btn.addEventListener("click", function() {
		reply_msg = prompt("Message for third song:", third_msg);
		if (reply_msg != null)
			third_msg = reply_msg;
	}, false);

	// start/stop button pressed
	function start_btn_press() {
		if (start_btn.innerHTML == "Tequila!") {
			lower_time = document.getElementById("lower-time").value;
			upper_time = document.getElementById("upper-time").value;
			if (lower_time > upper_time) {
				alert("The lower time range cannot be greater than the upper time range!");
				return;
			}
			if (lower_time < 0) {
				alert("The time range cannot be negative!");
				return;
			}
			start_btn.innerHTML = "Stop";
			startTimer();
		} else {
			start_btn.innerHTML = "Tequila!";
			stopAll(true);
		}
	}

	// start timer to trigger
	function startTimer() {
		// randomise time within range
		var timerVal = getRandom(lower_time * 60, upper_time * 60) * 1000;
		timer = setTimeout(function() { playSong(); }, timerVal);
	}

	// play different songs and swap mexican image for animated gif
	function playSong() {
		document.getElementById("sombrero-img").src = "images/sombrero.gif";
		skip_btn.disabled = false;
		var ranSong = getRandom(1, 3);
		if (ranSong == 1) {
			document.getElementById('tequila-audio').play();
			changeMessage(first_msg);
		} else if (ranSong == 2) {
			document.getElementById('jelly-audio').play();
			changeMessage(second_msg);
		} else {
			document.getElementById('tequila2-audio').play();
			changeMessage(third_msg);
		}
		
		// duration song plays for
		timer2 = setTimeout(function() { stopAll(false) }, play_duration * 1000);
	}

	// skip or break out of loop
	function stopAll(breakLoop) {
		document.getElementById("sombrero-img").src = "images/sombrero.png";
		skip_btn.disabled = true;
		document.getElementById('tequila-audio').pause();
		document.getElementById('tequila-audio').currentTime = 0;
		document.getElementById('jelly-audio').pause();
		document.getElementById('jelly-audio').currentTime = 0;
		document.getElementById('tequila2-audio').pause();
		document.getElementById('tequila2-audio').currentTime = 0;
		clearTimeout(timer);
		clearTimeout(timer2);
		// if ticked, loop
		if (document.getElementById('loop-check').checked == true && breakLoop == false) {
			startTimer();
		} else {
			start_btn.innerHTML = "Tequila!";
			changeMessage("Everyone must consume when a song plays!");
		}
	}
	
	// random integer in range
	function getRandom(min, max) {
		return Math.floor(Math.random() * (max - min + 1)) + min;
	}
	
	// change display message
	function changeMessage(msg) {
		document.getElementById('message-box').innerHTML = msg;
	}
}, false);