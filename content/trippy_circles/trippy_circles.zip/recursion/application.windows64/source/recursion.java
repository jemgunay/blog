import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class recursion extends PApplet {

//size of largest circle
float startRadius = 2000.f;

// states/changes in motion & colour
int motionStyle = 0;
int motionStyleStates = 3;
int renderStyle = 0;
int renderStyleStates = 3;
float shift = 0.f;
int colourShift = 0;

// transition timer
boolean timing = true;
float time = 0;
float wait = 5000;

public void setup() {
  
  frameRate(60);
  
  shapeMode(CENTER);
  noFill();
  
  
  switchRenderStyle(0, true);
}

public void draw() {
  colorMode(RGB, 100);
  background(0);
  
  // check timer, transition
  if (timing && (millis() - time >= wait)) {
    switchRenderStyle(renderStyle+1, true);
  }

  drawCircles(width/2, height/2, startRadius);
}

public void drawCircles(float x, float y, float radius) {
  // current circle colour and rate of change
  int col = PApplet.parseInt(colourShift % 100);
  colourShift += 1;
    
  // rainbow
  if (renderStyle == 0) {
    colorMode(HSB, 100);
    stroke(col, 100, 100);
  }
  // rainbow inverse
  else if (renderStyle == 1) {
    colorMode(HSB, 100);
    col = PApplet.parseInt(map(radius, startRadius, 20, 100, 0));
    stroke(col, 100, 100);
  }
  // b/w
  else if (renderStyle == 2) {
    colorMode(RGB, 100);
    stroke(col);
  }
  // b/w inverse
  else if (renderStyle == 3) {
    colorMode(RGB, 100);
    col = PApplet.parseInt(map(radius, startRadius, 20, 0, 100));
    stroke(col);
  }

  // draw circle
  ellipse(x, y, radius, radius);

  // warp position and radius
  if (radius > 10) {
    radius *= 0.95f;
    shift += radians(0.01f);

    // alter x
    if (motionStyle == 0 || motionStyle == 3) x += (sin(shift) * radius * 0.02f);
    else if (motionStyle == 1) x += (cos(shift) * radius * 0.02f);
    else if (motionStyle == 2) x += (tan(shift) * radius * 0.02f);

    // alter y
    if (motionStyle == 3) y += (-abs(cos(shift*shift)) * radius * 0.01f) + (abs(tan(shift)) * radius * 0.01f);
    else y += (cos(shift) * radius * 0.04f) / 5.f;

    drawCircles(x, y, radius);
  }
}

// switch render style via timer or key press
public void switchRenderStyle(int state, boolean timed) {
  if (state > renderStyleStates) {
    state = 0;
  }
  
  if (timed) {
    time = millis();
  } else {
    timing = false;
  }
  
  renderStyle = state;
}

public void keyPressed() {
  if (key == CODED) {
    // changing motion style
    if (keyCode == RIGHT) {
      if (motionStyle < motionStyleStates) motionStyle++;
      else motionStyle = 0;
    }
    if (keyCode == LEFT) {
      if (motionStyle > 0) motionStyle--;
      else motionStyle = motionStyleStates;
    }
  } else {
    // changing render style
    if (key == '1') switchRenderStyle(0, false);
    else if (key == '2') switchRenderStyle(1, false);
    else if (key == '3') switchRenderStyle(2, false);
    else if (key == '4') switchRenderStyle(3, false);
  }
}
  public void settings() {  size(1800, 900);  smooth(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "recursion" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
